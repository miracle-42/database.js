Github don't accept empty directories.
